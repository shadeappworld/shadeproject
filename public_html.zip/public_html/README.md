# shade notes

## How to download the project?

Click on the clone/download button and download it as zip.

Extract the zip by right clicking and extract it to your preferred location

## How to run the project

Double click index.html file.
